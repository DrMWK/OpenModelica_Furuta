# -*- coding: utf-8 -*-

"""
Bodeplot aus Zeitbereichsdaten via FFT

Verbesserungen:
- stabile Phasenberechnung (keine 360°-Sprünge durch Glättung)
- optionale komplexe Glättung (Real/Imag statt Phase)

Ausgabe:
- nur Amplitudengang
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

# ==================================================
# Einstellungen
# ==================================================

files = [
    "Stoergr_12s_St_1.csv",
    "Stoergr_12s_St_2.csv",
    "Stoergr_12s_St_3.csv"
]

colors = ["red", "blue", "green"]

start_time = 2
end_time = 12

col_time = 0
col_output = 1
col_input = 10

f_min = 5
f_max = 1000

# ==================================================
# Glättung
# ==================================================

SMOOTHING = True
SMOOTH_WINDOW = 21      # ungerade Zahl
SMOOTH_POLY = 6

def smooth(x):
    if not SMOOTHING:
        return x
    if len(x) < SMOOTH_WINDOW:
        return x
    return savgol_filter(x, SMOOTH_WINDOW, SMOOTH_POLY)

# ==================================================
# Plot
# ==================================================

fig, ax1 = plt.subplots(figsize=(14, 9))

fig.suptitle(
    "Amplitudengang Störgrößen-Übertragungsverhalten",
    fontsize=20,
    fontweight="bold"
)

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    df = pd.read_csv(file)

    time = df.iloc[:, col_time].to_numpy()
    y = df.iloc[:, col_output].to_numpy()
    u = df.iloc[:, col_input].to_numpy()

    column_names = df.columns.tolist()

    legend_label = (
        f"{os.path.basename(file)} - "
        f"{column_names[col_input]} - "
        f"{column_names[col_output]}"
    )

    # ------------------------------------------
    # Zeitfenster
    # ------------------------------------------
    mask = (time >= start_time) & (time <= end_time)

    time_w = time[mask]
    u_w = u[mask]
    y_w = y[mask]

    # ------------------------------------------
    # DC entfernen
    # ------------------------------------------
    u_w = u_w - np.mean(u_w)
    y_w = y_w - np.mean(y_w)

    # ------------------------------------------
    # Fensterfunktion
    # ------------------------------------------
    window = np.hanning(len(time_w))
    u_w = u_w * window
    y_w = y_w * window

    # ------------------------------------------
    # FFT
    # ------------------------------------------
    dt = np.mean(np.diff(time_w))
    N = len(time_w)

    U = np.fft.fft(u_w)
    Y = np.fft.fft(y_w)
    freq = np.fft.fftfreq(N, d=dt)

    # ------------------------------------------
    # positive Frequenzen
    # ------------------------------------------
    pos = freq > 0
    freq = freq[pos]
    U = U[pos]
    Y = Y[pos]

    # ------------------------------------------
    # Übertragungsfunktion
    # ------------------------------------------
    eps = 1e-12
    valid = np.abs(U) > eps

    freq = freq[valid]
    U = U[valid]
    Y = Y[valid]

    G = Y / U

    # ------------------------------------------
    # Frequenzband
    # ------------------------------------------
    band = (freq >= f_min) & (freq <= f_max)
    freq = freq[band]
    G = G[band]

    # ==================================================
    # Optionale komplexe Glättung
    # ==================================================
    if SMOOTHING:
        G = smooth(G.real) + 1j * smooth(G.imag)

    # ------------------------------------------
    # Bode-Daten
    # ------------------------------------------
    magnitude_db = 20 * np.log10(np.abs(G))

    # ------------------------------------------
    # Plot
    # ------------------------------------------
    ax1.semilogx(
        freq,
        magnitude_db,
        color=color,
        linewidth=2,
        label=legend_label
    )

# ==================================================
# Layout Amplitude
# ==================================================

ax1.set_title("Amplitudenverstärkung - In: Störung Sollposition Pendel (rad) / Out: Position Pendel (rad)", fontsize=18)
ax1.set_xlabel("Frequenz [Hz]", fontsize=16)
ax1.set_ylabel("Amplitude [dB]", fontsize=16)

ax1.set_xlim(f_min, f_max)

ax1.grid(True, which="both", linestyle="--", alpha=0.6)
ax1.legend(fontsize=11, loc="lower left")
ax1.tick_params(axis="both", labelsize=14)

# ==================================================
# Skriptname rechts unten
# ==================================================

try:
    script_name = os.path.basename(__file__)
except NameError:
    script_name = "interactive_session"

fig.text(
    0.99,
    0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=10,
    color="gray"
)

# ==================================================
# Final Layout
# ==================================================

plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()