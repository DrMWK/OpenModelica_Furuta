# -*- coding: utf-8 -*-
"""
Created on Fri Jun 12 19:21:17 2026

@author: DMK
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jun  9 20:21:25 2026

@author: DMK
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ==================================================
# Dateien
# ==================================================

files = [
    "Drop_5_St1_10deg.csv",
    "Drop_5_St2_10deg.csv",
    "Drop_5_St3_10deg.csv"
]

colors = ["red", "blue", "green"]

# ==================================================
# Allgemein
# ==================================================

fft_max_freq = 150.0
fft_min_freq = 1.0
start_time = 6.0

# gemeinsame Schriftgröße

font_size = 14
legend_font_size = font_size - 2

figure_title = "geregeltes Furuta-Pendel - quasistationäres Verhalten"

# ==================================================
# FFT 1 Parameter
# ==================================================

fft1_signal_column_index = 2

fft1_ampl_min = 0.000001
fft1_ampl_max = 10
fft1_y_scale = "log"      # "linear" oder "log"

fft1_smooth_points = 6
fft1_title = "FFT Winkelgeschwindigkeit Pendel (rad/s)"

# ==================================================
# FFT 2 Parameter
# ==================================================

fft2_signal_column_index = 6

fft2_ampl_min = 0.00001
fft2_ampl_max = 1000
fft2_y_scale = "log"      # "linear" oder "log"

fft2_smooth_points = 2
fft2_title = "FFT Winkelbeschleunigung Rotor (rad/s^2)"

# ==================================================
# Plot
# ==================================================

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 9))

fig.suptitle(
    figure_title,
    fontsize=font_size + 2,
    fontweight="bold"
)

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    df = pd.read_csv(file)
    column_names = df.columns.tolist()

    time = df.iloc[:, 0].to_numpy()

    signal1 = df.iloc[:, fft1_signal_column_index].to_numpy()
    signal2 = df.iloc[:, fft2_signal_column_index].to_numpy()

    signal1_name = column_names[fft1_signal_column_index]
    signal2_name = column_names[fft2_signal_column_index]

    # ----------------------------------------------
    # Zeitfilter
    # ----------------------------------------------

    mask = time >= start_time

    time = time[mask]
    signal1 = signal1[mask]
    signal2 = signal2[mask]

    # DC entfernen

    signal1 = signal1 - np.mean(signal1)
    signal2 = signal2 - np.mean(signal2)

    dt = np.mean(np.diff(time))

    # ==================================================
    # FFT 1
    # ==================================================

    N1 = len(signal1)

    window1 = np.hanning(N1)
    sig1w = signal1 * window1

    fft1 = np.fft.rfft(sig1w)
    freq1 = np.fft.rfftfreq(N1, d=dt)

    ampl1 = 2.0 / np.sum(window1) * np.abs(fft1)
    ampl1[0] /= 2

    valid1 = freq1 >= fft_min_freq

    freq1 = freq1[valid1]
    ampl1 = ampl1[valid1]

    ampl1_smooth = np.convolve(
        ampl1,
        np.ones(fft1_smooth_points) / fft1_smooth_points,
        mode="same"
    )

    mask1 = freq1 <= fft_max_freq

    peak1 = np.argmax(ampl1_smooth[mask1])

    peak_freq1 = freq1[mask1][peak1]
    peak_amp1 = ampl1_smooth[mask1][peak1]

    # ==================================================
    # FFT 2
    # ==================================================

    N2 = len(signal2)

    window2 = np.hanning(N2)
    sig2w = signal2 * window2

    fft2 = np.fft.rfft(sig2w)
    freq2 = np.fft.rfftfreq(N2, d=dt)

    ampl2 = 2.0 / np.sum(window2) * np.abs(fft2)
    ampl2[0] /= 2

    valid2 = freq2 >= fft_min_freq

    freq2 = freq2[valid2]
    ampl2 = ampl2[valid2]

    ampl2_smooth = np.convolve(
        ampl2,
        np.ones(fft2_smooth_points) / fft2_smooth_points,
        mode="same"
    )

    mask2 = freq2 <= fft_max_freq

    peak2 = np.argmax(ampl2_smooth[mask2])

    peak_freq2 = freq2[mask2][peak2]
    peak_amp2 = ampl2_smooth[mask2][peak2]

    # ==================================================
    # Ausgabe
    # ==================================================

    print(f"\nDatei: {file}")

    print(f"FFT1 ({signal1_name})")
    print(f"Peak f: {peak_freq1:.3f} Hz | Amp: {peak_amp1:.6f}")

    print(f"FFT2 ({signal2_name})")
    print(f"Peak f: {peak_freq2:.3f} Hz | Amp: {peak_amp2:.6f}")

    # ==================================================
    # Plot FFT 1
    # ==================================================

    ax1.plot(
        freq1,
        ampl1_smooth,
        color=color,
        linewidth=2,
        label=f"{os.path.basename(file)} | {signal1_name}"
    )

    # ==================================================
    # Plot FFT 2
    # ==================================================

    ax2.plot(
        freq2,
        ampl2_smooth,
        color=color,
        linewidth=2,
        label=f"{os.path.basename(file)} | {signal2_name}"
    )

# ==================================================
# Layout FFT 1
# ==================================================

ax1.set_title(fft1_title, fontsize=font_size)

# ax1.set_xlabel("Frequenz [Hz]", fontsize=font_size)

ax1.set_ylabel("Amplitude", fontsize=font_size)

ax1.set_xscale("linear")
ax1.set_yscale(fft1_y_scale)

ax1.set_xlim(fft_min_freq, fft_max_freq)
ax1.set_ylim(fft1_ampl_min, fft1_ampl_max)

ax1.grid(True, which="both")
ax1.legend(fontsize=legend_font_size, loc="upper left")
ax1.tick_params(labelsize=font_size)

# ==================================================
# Layout FFT 2
# ==================================================

ax2.set_title(fft2_title, fontsize=font_size)

ax2.set_xlabel("Frequenz [Hz]", fontsize=font_size)
ax2.set_ylabel("Amplitude", fontsize=font_size)

ax2.set_xscale("linear")
ax2.set_yscale(fft2_y_scale)

ax2.set_xlim(fft_min_freq, fft_max_freq)
ax2.set_ylim(fft2_ampl_min, fft2_ampl_max)

ax2.grid(True, which="both")
ax2.legend(fontsize=legend_font_size, loc="upper left")
ax2.tick_params(labelsize=font_size)

# ==================================================
# Anzeige
# ==================================================

script_name = (
    os.path.basename(__file__)
    if "__file__" in globals()
    else "unknown_script.py"
)

fig.text(
    0.99,
    0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=10,
    color="gray"
)

plt.tight_layout()
plt.show()