# -*- coding: utf-8 -*-
"""
Created on Tue Jun  9 20:21:25 2026

@author: DMK
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ==================================================
# Einstellungen
# ==================================================

files = [
    "Akt_Noise_StSt_1.csv",
    "Akt_Noise_StSt_2.csv",
    "Akt_Noise_StSt_3.csv"
]

colors = ["red", "blue", "green"]

start_time = 0
end_time = 5

zoom_start = 3
zoom_end = 3.05

col_top = 4
col_middle = 5
col_bottom = 6

# ==================================================
# Plot Layout
# ==================================================

fig, axes = plt.subplots(3, 2, figsize=(16, 10), sharey='row')

fig.suptitle(
    "Zeitverlauf Aktuatoranalyse mit Uniform Noise",
    fontsize=20,
    fontweight="bold"
)

titles = [
    ("Rotordrehzahl n (rpm)", "Rotordrehzahl n (rpm)"),
    ("Ist-Moment Aktuator (Nm)", "Ist-Moment Aktuator (Nm)"),
    ("Soll-Moment Aktuator (Nm)", "Soll-Moment Aktuator (Nm)")
]

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    df = pd.read_csv(file)
    column_names = df.columns.tolist()

    time = df.iloc[:, 0].to_numpy()

    sig_top = df.iloc[:, col_top].to_numpy()
    sig_mid = df.iloc[:, col_middle].to_numpy()
    sig_bot = df.iloc[:, col_bottom].to_numpy()

    name_top = column_names[col_top]
    name_mid = column_names[col_middle]
    name_bot = column_names[col_bottom]

    base = os.path.basename(file)

    # ------------------------------------------
    # LINKS (voll)
    # ------------------------------------------
    mask_full = (time >= start_time) & (time <= end_time)

    axes[0, 0].plot(
        time[mask_full],
        sig_top[mask_full],
        color=color,
        label=f"{base} | {name_top}"
    )

    axes[1, 0].plot(
        time[mask_full],
        sig_mid[mask_full],
        color=color,
        label=f"{base} | {name_mid}"
    )

    axes[2, 0].plot(
        time[mask_full],
        sig_bot[mask_full],
        color=color,
        label=f"{base} | {name_bot}"
    )

    # ------------------------------------------
    # RECHTS (Zoom 0.1–0.2 s, keine Zeitverschiebung)
    # ------------------------------------------
    mask_zoom = (time >= zoom_start) & (time <= zoom_end)

    axes[0, 1].plot(time[mask_zoom], sig_top[mask_zoom], color=color)
    axes[1, 1].plot(time[mask_zoom], sig_mid[mask_zoom], color=color)
    axes[2, 1].plot(time[mask_zoom], sig_bot[mask_zoom], color=color)

# ==================================================
# Styling
# ==================================================

for i in range(3):

    # Links
    axes[i, 0].set_title(titles[i][0], fontsize=14)
    axes[i, 0].grid(True)
    axes[i, 0].tick_params(labelsize=14)
    axes[i, 0].legend(fontsize=12, loc="lower right")

    # Rechts
    axes[i, 1].set_title(titles[i][1], fontsize=14)
    axes[i, 1].grid(True)
    axes[i, 1].tick_params(labelsize=12)

# X-Achsen
axes[2, 0].set_xlabel("Zeit [s]", fontsize=14)
axes[2, 1].set_xlabel("Zeit [s]", fontsize=14)

axes[1, 0].set_ylim(-1.4, 0.7)   # mittleres Diagramm links
axes[1, 1].set_ylim(-1.4, 0.7)   # mittleres Diagramm rechts

axes[2, 0].set_ylim(-1.4, 0.7)   # unteres Diagramm links
axes[2, 1].set_ylim(-1.4, 0.7)   # unteres Diagramm rechts


# Y-Achsen nur links
#axes[0, 0].set_ylabel("Amplitude", fontsize=13)
#axes[1, 0].set_ylabel("Amplitude", fontsize=13)
#axes[2, 0].set_ylabel("Amplitude", fontsize=13)

# ==================================================
# Dateiinfo
# ==================================================

script_name = os.path.basename(__file__) if "__file__" in globals() else "unknown_script.py"

fig.text(
    0.99, 0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=9,
    color="gray"
)

plt.tight_layout()
plt.show()