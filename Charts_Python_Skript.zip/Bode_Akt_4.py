# -*- coding: utf-8 -*-

"""
Bodeplot aus Zeitbereichsdaten via FFT

Verbesserungen:
- stabile Phasenberechnung (keine 360°-Sprünge durch Glättung)
- optionale komplexe Glättung (Real/Imag statt Phase)
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

# ==================================================
# Einstellungen
# ==================================================

files = [
    "Akt_Noise_StSt_1.csv",
    "Akt_Noise_StSt_2.csv",
    "Akt_Noise_StSt_3.csv"
]

colors = ["red", "blue", "green"]

start_time = 0
end_time = 5

col_time = 0
col_output = 5
col_input = 6
col_n_rot = 4

f_min = 1
f_max = 1000

# ==================================================
# Glättung
# ==================================================

SMOOTHING = True
SMOOTH_WINDOW = 11  # ungerade Zahl
SMOOTH_POLY = 2

def smooth(x):
    if not SMOOTHING:
        return x
    if len(x) < SMOOTH_WINDOW:
        return x
    return savgol_filter(x, SMOOTH_WINDOW, SMOOTH_POLY)

# ==================================================
# Plot
# ==================================================

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 9), sharex=True)

fig.suptitle(
    "Bodeplot des Aktuators Stufe 1,2,3",
    fontsize=20,
    fontweight="bold"
)

info_lines = []
info_lines.append(
    f"Auswertezeitraum {start_time}s – {end_time}s | Rotordrehzahl n_Rot (rpm)"
)

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    df = pd.read_csv(file)

    time = df.iloc[:, col_time].to_numpy()
    y = df.iloc[:, col_output].to_numpy()
    u = df.iloc[:, col_input].to_numpy()
    n_rot = df.iloc[:, col_n_rot].to_numpy()

    column_names = df.columns.tolist()

    legend_label = (
        f"{os.path.basename(file)} - "
        f"{column_names[col_input]} - "
        f"{column_names[col_output]}"
    )

    # ------------------------------------------
    # Zeitfenster
    # ------------------------------------------
    mask = (time >= start_time) & (time <= end_time)

    time_w = time[mask]
    u_w = u[mask]
    y_w = y[mask]
    n_rot_w = n_rot[mask]

    # ------------------------------------------
    # Statistik
    # ------------------------------------------
    info_lines.append(
        f"{os.path.basename(file)} | "
        f"min {np.min(n_rot_w):.2f} | "
        f"max {np.max(n_rot_w):.2f} | "
        f"mean {np.mean(n_rot_w):.2f}"
    )

    # ------------------------------------------
    # DC entfernen
    # ------------------------------------------
    u_w = u_w - np.mean(u_w)
    y_w = y_w - np.mean(y_w)

    # ------------------------------------------
    # Fensterfunktion
    # ------------------------------------------
    window = np.hanning(len(time_w))
    u_w = u_w * window
    y_w = y_w * window

    # ------------------------------------------
    # FFT
    # ------------------------------------------
    dt = np.mean(np.diff(time_w))
    N = len(time_w)

    U = np.fft.fft(u_w)
    Y = np.fft.fft(y_w)
    freq = np.fft.fftfreq(N, d=dt)

    # ------------------------------------------
    # positive Frequenzen
    # ------------------------------------------
    pos = freq > 0
    freq = freq[pos]
    U = U[pos]
    Y = Y[pos]

    # ------------------------------------------
    # Übertragungsfunktion
    # ------------------------------------------
    eps = 1e-12
    valid = np.abs(U) > eps

    freq = freq[valid]
    U = U[valid]
    Y = Y[valid]

    G = Y / U

    # ------------------------------------------
    # Frequenzband
    # ------------------------------------------
    band = (freq >= f_min) & (freq <= f_max)
    freq = freq[band]
    G = G[band]

    # ==================================================
    # OPTIONAL: komplexe Glättung (empfohlen!)
    # ==================================================
    if SMOOTHING:
        G = smooth(G.real) + 1j * smooth(G.imag)

    # ------------------------------------------
    # Bode Daten
    # ------------------------------------------
    magnitude_db = 20 * np.log10(np.abs(G))

    # WICHTIG: unwrap VOR Umrechnung + KEINE Glättung!
    phase_rad = np.unwrap(np.angle(G))
    phase_deg = np.rad2deg(phase_rad)

    # ------------------------------------------
    # Plot
    # ------------------------------------------
    ax1.semilogx(freq, magnitude_db, color=color, linewidth=2, label=legend_label)
    ax2.semilogx(freq, phase_deg, color=color, linewidth=2, label=legend_label)

# ==================================================
# Layout Amplitude
# ==================================================

ax1.set_title("Amplitudengang", fontsize=18)
ax1.set_ylabel("Amplitude [dB]", fontsize=16)
ax1.set_xlim(1, 1000)
ax1.grid(True, which="both", linestyle="--", alpha=0.6)
ax1.legend(fontsize=11, loc="lower left")
ax1.tick_params(axis='both', labelsize=14)

# ==================================================
# Layout Phase
# ==================================================

ax2.set_title("Phasengang", fontsize=18)
ax2.set_xlabel("Frequenz [Hz]", fontsize=16)
ax2.set_ylabel("Phase [°]", fontsize=16)
ax2.set_xlim(1, 1000)
ax2.grid(True, which="both", linestyle="--", alpha=0.6)
ax2.legend(fontsize=11, loc="lower left")
ax2.tick_params(axis='both', labelsize=14)

# ==================================================
# Scriptname Fix
# ==================================================

script_name = os.path.basename(__file__) if "__file__" in globals() else "interactive_session"

fig.text(
    0.99, 0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=10,
    color="gray"
)

# ==================================================
# Info Box
# ==================================================

textbox_text = "\n".join(info_lines)

pos = ax2.get_position()

fig.text(
    0.09,
    pos.y0 + 0.08,
    textbox_text,
    ha="left",
    va="bottom",
    fontsize=9,
    family="monospace",
    bbox=dict(boxstyle="round", facecolor="white", alpha=0.85)
)

# ==================================================
# Final Layout
# ==================================================

plt.tight_layout()
plt.show()