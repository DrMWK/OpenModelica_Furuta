# -*- coding: utf-8 -*-
"""
Created on Tue Jun  9 20:21:25 2026

@author: DMK
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ==================================================
# Einstellungen
# ==================================================

files = [
    "Drop_max_St1_57deg.csv",
    "Drop_max_St2_56deg.csv",
    "Drop_max_St3_50deg.csv"
]

colors = ["red", "blue", "green"]

start_time = 0
end_time = 0.55

# Spaltenwahl
col_top = 1     # oben im Plot
col_bottom = 5  # unten im Plot

# ==================================================
# Plot vorbereiten
# ==================================================

Title_oben = "phi Pendel (rad)"
Title_unten = "w Rotor (rad/s)"

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 9))

fig.suptitle(
    "Pendel einfangen aus Maximalauslenkung",
    fontsize=20,
    fontweight="bold"
)

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    # ----------------------------------------------
    # CSV einlesen
    # ----------------------------------------------
    df = pd.read_csv(file)
    column_names = df.columns.tolist()

    time = df.iloc[:, 0].to_numpy()

    signal_top = df.iloc[:, col_top].to_numpy()
    signal_bottom = df.iloc[:, col_bottom].to_numpy()

    name_top = column_names[col_top]
    name_bottom = column_names[col_bottom]

    # ----------------------------------------------
    # Zeitfilter
    # ----------------------------------------------
    mask = (time >= start_time) & (time <= end_time)

    time = time[mask]
    signal_top = signal_top[mask]
    signal_bottom = signal_bottom[mask]

    time_plot = time - time[0]

    # DC entfernen (optional)
    # signal_top = signal_top - np.mean(signal_top)
    # signal_bottom = signal_bottom - np.mean(signal_bottom)

    # ----------------------------------------------
    # Legende
    # ----------------------------------------------
    label_top = f"{os.path.basename(file)} | {name_top}"
    label_bottom = f"{os.path.basename(file)} | {name_bottom}"

    # ----------------------------------------------
    # Plot oben
    # ----------------------------------------------
    ax1.plot(
        time_plot,
        signal_top,
        color=color,
        label=label_top
    )

    # ----------------------------------------------
    # Plot unten
    # ----------------------------------------------
    ax2.plot(
        time_plot,
        signal_bottom,
        color=color,
        label=label_bottom
    )

# ==================================================
# Layout
# ==================================================

# ---- Oberer Plot ----
ax1.set_title(Title_oben, fontsize=18)
#ax1.set_ylabel("Amplitude", fontsize=16)

# X-Achse im oberen Plot deaktivieren (wie gewünscht)
ax1.set_xlabel("")
ax1.tick_params(axis='x', labelbottom=False)
ax1.tick_params(axis='y', labelsize=14)

ax1.grid(True)
ax1.legend(fontsize=12)

# ---- Unterer Plot ----
ax2.set_title(Title_unten, fontsize=18)
ax2.set_xlabel("Zeit [s]", fontsize=16)
#ax2.set_ylabel("Amplitude", fontsize=16)

ax2.tick_params(axis='both', labelsize=14)

ax2.grid(True)
ax2.legend(fontsize=12)

# ==================================================
# Dateiinfo im Plot
# ==================================================

script_name = os.path.basename(__file__) if "__file__" in globals() else "unknown_script.py"

fig.text(
    0.99, 0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=10,
    color="gray"
)

plt.tight_layout()
plt.show()
