# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
"""
Created on Tue Jun  9 20:21:25 2026

@author: DMK
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ==================================================
# Einstellungen
# ==================================================

files = [
    "Drop_5_St1_10deg.csv",
    "Drop_5_St2_10deg.csv",
    "Drop_5_St3_10deg.csv"
]

colors = ["red", "blue", "green"]

start_time = 11.9
end_time = 12.0

# Spaltenwahl
col_top = 5      # oben im Plot (z.B. Drehzahl)
col_bottom = 7   # unten im Plot (z.B. Moment)

# ==================================================
# Plot vorbereiten
# ==================================================

Title_oben = "w Rotor (rad/s)"
Title_unten = "Ist-Moment (Nm)"
Title_leistung = "Momentanleistung (W)"

fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(14, 12))

fig.suptitle(
    "Dynamikgroessen im quasistationären Zustand",
    fontsize=16,
    fontweight="bold"
)

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    # ----------------------------------------------
    # CSV einlesen
    # ----------------------------------------------
    df = pd.read_csv(file)
    column_names = df.columns.tolist()

    time = df.iloc[:, 0].to_numpy()

    signal_top = df.iloc[:, col_top].to_numpy()
    signal_bottom = df.iloc[:, col_bottom].to_numpy()

    # Leistung
    P_ist = signal_top * signal_bottom

    name_top = column_names[col_top]
    name_bottom = column_names[col_bottom]

    # ----------------------------------------------
    # Zeitfilter
    # ----------------------------------------------
    mask = (time >= start_time) & (time <= end_time)

    time = time[mask]
    signal_top = signal_top[mask]
    signal_bottom = signal_bottom[mask]
    P_ist = P_ist[mask]

    time_plot = time

    # ----------------------------------------------
    # RMS / Effektivwerte
    # ----------------------------------------------
    rms_top = np.sqrt(np.mean(signal_top**2))
    rms_bottom = np.sqrt(np.mean(signal_bottom**2))
    rms_power = np.sqrt(np.mean(P_ist**2))

    print(f"\nDatei: {os.path.basename(file)}")
    print(f"  RMS {name_top}:    {rms_top:.6f}")
    print(f"  RMS {name_bottom}: {rms_bottom:.6f}")
    print(f"  RMS P_ist:         {rms_power:.6f}")

    # ----------------------------------------------
    # Legenden
    # ----------------------------------------------
    label_top = f"{os.path.basename(file)} | {name_top}"
    label_bottom = f"{os.path.basename(file)} | {name_bottom}"
    label_power = f"{os.path.basename(file)} | P_ist"

    # ----------------------------------------------
    # Plot oben
    # ----------------------------------------------
    ax1.plot(time_plot, signal_top, color=color, label=label_top)

    # ----------------------------------------------
    # Plot Mitte
    # ----------------------------------------------
    ax2.plot(time_plot, signal_bottom, color=color, label=label_bottom)

    # ----------------------------------------------
    # Plot unten
    # ----------------------------------------------
    ax3.plot(time_plot, P_ist, color=color, label=label_power)

# ==================================================
# Layout
# ==================================================

ax1.set_title(Title_oben)
ax1.set_xlabel("Zeit [s]")
#ax1.set_ylabel("Amplitude")
ax1.grid(True)
ax1.legend(loc="lower right")
ax1.set_ylim(-10, 5)

ax2.set_title(Title_unten)
ax2.set_xlabel("Zeit [s]")
#ax2.set_ylabel("Amplitude")
ax2.grid(True)
ax2.legend(loc="lower right")
ax2.set_ylim(-1.2, 0.6)

ax3.set_title(Title_leistung)
ax3.set_xlabel("Zeit [s]")
#ax3.set_ylabel("Leistung [W]")
ax3.grid(True)
ax3.legend(loc="lower right")
ax3.set_ylim(-3.5, 1.5)

# gleiche Zeitachse
ax1.set_xlim(start_time, end_time)
ax2.set_xlim(start_time, end_time)
ax3.set_xlim(start_time, end_time)

# Skriptname sauber setzen
script_name = os.path.basename(__file__)

fig.text(
    0.99, 0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=10,
    color="gray"
)

plt.tight_layout()
plt.show()