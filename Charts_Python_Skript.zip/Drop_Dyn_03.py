

# -*- coding: utf-8 -*-
"""
Created on Tue Jun  9 20:21:25 2026
@author: DMK
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ==================================================
# Einstellungen
# ==================================================

files = [
    "Drop_max_St1_57deg.csv",
    "Drop_max_St2_56deg.csv",
    "Drop_max_St3_50deg.csv"
]

colors = ["red", "blue", "green"]

start_time = 0
end_time =     0.05

# Spaltenwahl
col_rot = 5      # Winkelgeschwindigkeit [rad/s]
col_bottom = 7   # Moment [Nm]

# ==================================================
# Plot vorbereiten
# ==================================================

Title_oben = "Momentandrehzahl n Rotor (rpm)"
Title_unten = "Ist-Moment (Nm)"
Title_leistung = "Momentanleistung (W)"

fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(14, 12))

fig.suptitle(
    "Pendel einfangen aus Maximalauslenkung",
    fontsize=16,
    fontweight="bold"
)

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    # ----------------------------------------------
    # CSV einlesen
    # ----------------------------------------------
    df = pd.read_csv(file)
    column_names = df.columns.tolist()

    time = df.iloc[:, 0].to_numpy()

    omega = df.iloc[:, col_rot].to_numpy()        # rad/s
    moment = df.iloc[:, col_bottom].to_numpy()

    # Drehzahl in rpm
    n_Rot = omega * 60 / (2 * np.pi)

    # Leistung
    P_ist = omega * moment

    name_rot = column_names[col_rot]
    name_bottom = column_names[col_bottom]

    # ----------------------------------------------
    # Zeitfilter
    # ----------------------------------------------
    mask = (time >= start_time) & (time <= end_time)

    time = time[mask]
    n_Rot = n_Rot[mask]
    moment = moment[mask]
    P_ist = P_ist[mask]

    time_plot = time - time[0]

    # ----------------------------------------------
    # DC entfernen (optional)
    # ----------------------------------------------
#    n_Rot = n_Rot - np.mean(n_Rot)
#    moment = moment - np.mean(moment)
#    P_ist = P_ist - np.mean(P_ist)

    # ----------------------------------------------
    # MIN / MAX AUSGABE
    # ----------------------------------------------
    n_min, n_max = np.min(n_Rot), np.max(n_Rot)
    m_min, m_max = np.min(moment), np.max(moment)
    p_min, p_max = np.min(P_ist), np.max(P_ist)

    print("\n======================================")
    print(f"Datei: {os.path.basename(file)}")
    print("--------------------------------------")
    print(f"{name_rot} (rpm):   min = {n_min:.3f}, max = {n_max:.3f}")
    print(f"{name_bottom} (Nm): min = {m_min:.3f}, max = {m_max:.3f}")
    print(f"Leistung (W):       min = {p_min:.3f}, max = {p_max:.3f}")
    print("======================================\n")

    # ----------------------------------------------
    # Legenden
    # ----------------------------------------------
    label_rot = f"{os.path.basename(file)} | n_Rot (rpm)"
    label_bottom = f"{os.path.basename(file)} | {name_bottom}"
    label_power = f"{os.path.basename(file)} | P_ist"

    # ----------------------------------------------
    # Plot oben: Drehzahl
    # ----------------------------------------------
    ax1.plot(time_plot, n_Rot, color=color, label=label_rot)

    # ----------------------------------------------
    # Plot Mitte: Moment
    # ----------------------------------------------
    ax2.plot(time_plot, moment, color=color, label=label_bottom)

    # ----------------------------------------------
    # Plot unten: Leistung
    # ----------------------------------------------
    ax3.plot(time_plot, P_ist, color=color, label=label_power)

# ==================================================
# Layout
# ==================================================

ax1.set_title(Title_oben)
ax1.set_xlabel("Zeit [s]")
ax1.set_ylabel("Drehzahl [rpm]")
ax1.grid(True)
ax1.legend(loc="lower left")

ax2.set_title(Title_unten)
ax2.set_xlabel("Zeit [s]")
ax2.set_ylabel("Moment [Nm]")
ax2.grid(True)
ax2.legend(loc="upper left")

ax3.set_title(Title_leistung)
ax3.set_xlabel("Zeit [s]")
ax3.set_ylabel("Leistung [W]")
ax3.grid(True)
ax3.legend(loc="upper left")

# Script-Name robust bestimmen
try:
    script_name = os.path.basename(__file__)
except NameError:
    script_name = "interactive_session.py"

fig.text(
    0.99, 0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=10,
    color="gray"
)

plt.tight_layout()
plt.show()