# -*- coding: utf-8 -*-
"""
Created on Tue Jun  9 20:21:25 2026

@author: DMK
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ==================================================
# SCHRIFTEINSTELLUNG (zentral steuerbar)
# ==================================================

FONT_SIZE = 14
TITLE_SIZE = 22
LABEL_SIZE = 16
TICK_SIZE = 13
LEGEND_SIZE = 12

plt.rcParams.update({
    "font.size": FONT_SIZE
})

# ==================================================
# Einstellungen
# ==================================================

files = [
    "Drop_5_St1_10deg.csv",
    "Drop_5_St2_10deg.csv",
    "Drop_5_St3_10deg.csv"
]

colors = ["red", "blue", "green"]

start_time = 11.85
end_time = 12.0

# Spaltenwahl
col_top = 1      # oben im Plot
col_bottom = 5   # unten im Plot

# ==================================================
# Plot vorbereiten
# ==================================================

Title_oben = "phi Pendel (rad)"
Title_unten = "w Rotor (rad/s)"

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 9))

fig.suptitle(
    "Pendel im quasistationären Zustand",
    fontsize=TITLE_SIZE,
    fontweight="bold"
)

# ==================================================
# Verarbeitung
# ==================================================

for file, color in zip(files, colors):

    # ----------------------------------------------
    # CSV einlesen
    # ----------------------------------------------
    df = pd.read_csv(file)
    column_names = df.columns.tolist()

    time = df.iloc[:, 0].to_numpy()

    signal_top = df.iloc[:, col_top].to_numpy()
    signal_bottom = df.iloc[:, col_bottom].to_numpy()

    name_top = column_names[col_top]
    name_bottom = column_names[col_bottom]

    # ----------------------------------------------
    # Zeitfilter
    # ----------------------------------------------
    mask = (time >= start_time) & (time <= end_time)

    time = time[mask]
    signal_top = signal_top[mask]
    signal_bottom = signal_bottom[mask]

    # WICHTIG: keine Zeitverschiebung mehr!
    time_plot = time

    # ----------------------------------------------
    # Statistik ausgeben
    # ----------------------------------------------
    min_top = np.min(signal_top)
    max_top = np.max(signal_top)

    min_bottom = np.min(signal_bottom)
    max_bottom = np.max(signal_bottom)

    print("\n" + "=" * 70)
    print(f"Datei: {os.path.basename(file)}")
    print(f"Zeitfenster: {start_time:.3f} s bis {end_time:.3f} s")
    print("-" * 70)

    print(f"{name_top}")
    print(f"  Min : {min_top:.6f}")
    print(f"  Max : {max_top:.6f}")
    print(f"  Δ   : {max_top - min_top:.6f}")

    print()

    print(f"{name_bottom}")
    print(f"  Min : {min_bottom:.6f}")
    print(f"  Max : {max_bottom:.6f}")
    print(f"  Δ   : {max_bottom - min_bottom:.6f}")

    print("=" * 70)

    # ----------------------------------------------
    # Legende
    # ----------------------------------------------
    label_top = f"{os.path.basename(file)} | {name_top}"
    label_bottom = f"{os.path.basename(file)} | {name_bottom}"

    # ----------------------------------------------
    # Plot oben
    # ----------------------------------------------
    ax1.plot(
        time_plot,
        signal_top,
        color=color,
        label=label_top
    )

    # ----------------------------------------------
    # Plot unten
    # ----------------------------------------------
    ax2.plot(
        time_plot,
        signal_bottom,
        color=color,
        label=label_bottom
    )

# ==================================================
# Layout
# ==================================================

ax1.set_title(Title_oben, fontsize=TITLE_SIZE)
ax1.set_xlabel("Zeit [s]", fontsize=LABEL_SIZE)
#ax1.set_ylabel("Amplitude", fontsize=LABEL_SIZE)
ax1.tick_params(axis='both', labelsize=TICK_SIZE)
ax1.grid(True)
ax1.legend(fontsize=LEGEND_SIZE, loc="upper right")
ax1.set_ylim(-0.01, 0.02)

ax2.set_title(Title_unten, fontsize=TITLE_SIZE)
ax2.set_xlabel("Zeit [s]", fontsize=LABEL_SIZE)
#ax2.set_ylabel("Amplitude", fontsize=LABEL_SIZE)
ax2.tick_params(axis='both', labelsize=TICK_SIZE)
ax2.grid(True)
ax2.legend(fontsize=LEGEND_SIZE, loc="upper right")
ax2.set_ylim(-5, 10)

# ==================================================
# Skriptname
# ==================================================

script_name = os.path.basename(__file__) if "__file__" in globals() else "interactive_session"

fig.text(
    0.99,
    0.01,
    script_name,
    ha="right",
    va="bottom",
    fontsize=10,
    color="gray"
)

plt.tight_layout()
plt.show()